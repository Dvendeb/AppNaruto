<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Verifica tu correo Electronico</title>
</head>
<body>
<p>Hola buen dia <?php echo e($user->name); ?> <?php echo e($user->last_name_f); ?>, sentimos mucho que hayas perdido tu contraseña</p>
<p>te hemos mandado una contraseña de repuesto que deberas cambiar al instante</p>
<p> <h1><?php echo e($newPassword); ?></h1></p>


</body>
</html>
<?php /**PATH C:\Users\dvend\ProyectosGit\NarutoAPI\resources\views/emails/safePassword.blade.php ENDPATH**/ ?>